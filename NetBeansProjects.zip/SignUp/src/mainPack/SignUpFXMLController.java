/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package mainPack;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import java.lang.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Sazzad
 */
public class SignUpFXMLController implements Initializable {

    @FXML
    private TextField tfUsername;
    @FXML
    private Button btnSignIn;
    @FXML
    private Label lblOutput;
    @FXML
    private PasswordField pfPassword;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void btnSignInClicked(ActionEvent event) {
        String userName = tfUsername.getText();
        String password = pfPassword.getText();
        
        if( userName.equals("sazzad") && password.equals("120109")){
            Data.data = userName;
            lblOutput.setText(Data.data);
            
            try {
                Scene scene = new Scene(FXMLLoader.load(getClass().getResource("MainMenuFXML.fxml")));
                
                Stage stage = new Stage();
                stage.setTitle("Main Menu");
                stage.setScene(scene);
                stage.show();
            } catch (IOException ex) {
                Logger.getLogger(SignUpFXMLController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        else{
            Data.data = userName;
            lblOutput.setText(Data.data);
        }
    }
    
}
