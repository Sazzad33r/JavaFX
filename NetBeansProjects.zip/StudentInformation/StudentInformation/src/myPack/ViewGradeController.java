package myPack;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Sazzad
 */
public class ViewGradeController implements Initializable {

    @FXML
    private TextField tfID;
    @FXML
    private Label lbMMid;
    @FXML
    private Label lbSMid;
    @FXML
    private Label lbEMid;
    @FXML
    private Label lbMFinal;
    @FXML
    private Label lbSFinal;
    @FXML
    private Label lbEFinal;
    @FXML
    private Label lbMGrade;
    @FXML
    private Label lbSGrade;
    @FXML
    private Label lbEGrade;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void btnViewClick(ActionEvent event) throws IOException {
        
        String ID = tfID.getText();
        
        List<String> student = new ArrayList<String>();
        
        if(ID.equals("")){
            Alert a = new Alert(Alert.AlertType.ERROR);
            a.setContentText("Please Enter An ID");
            a.show();
        }else{
            //String curDir = System.getProperty("user.dir");
            //String fileName = curDir + "\"" + ID + ".txt";
            
            String fileName = ID + ".txt";
            
            File file1 = new File(fileName);
            
            if(file1.exists()){
                   
                try {
                    BufferedReader bf = new BufferedReader(
                    new FileReader(fileName));
                    
                    String line = bf.readLine();
                    
                    while (line != null) {
                        student.add(line);
                        line = bf.readLine();
                        
                        
                        }
                    
                    
                    bf.close();
                    
                    String[] array = student.toArray(new String[0]);
                    String[] arrOfStr = array[0].split("&");
                    
                    int fM = 0;
                    int fS = 0;
                    int fE = 0;
                    //System.out.println(arrOfStr.length);
                    if(arrOfStr.length > 12){
                       if(arrOfStr[5].equalsIgnoreCase("math")){
                           fM = 1;
                           int mid = Integer.parseInt(arrOfStr[6]);
                           int fin = Integer.parseInt(arrOfStr[7]);
                           
                           int total = mid + fin;
                           
                           //System.out.println(total);
                           
                           lbMFinal.setText(String.valueOf(fin));
                           lbMMid.setText(String.valueOf(mid));
                           
                           if (total >= 80) {
                               lbMGrade.setText("A");
                           } else if (total >= 60 && total < 80) {
                               lbMGrade.setText("B");
                           } else if (total >= 50 && total < 60) {
                               lbMGrade.setText("C");
                           } else if (total >= 40 && total < 50) {
                               lbMGrade.setText("D");
                           } else {
                               lbMGrade.setText("F");
                           }
                       }
                       if(arrOfStr[8].equalsIgnoreCase("math")){
                           fM = 1;
                           int mid = Integer.parseInt(arrOfStr[9]);
                           int fin = Integer.parseInt(arrOfStr[10]);
                           int total = mid + fin;
                           
                           lbMFinal.setText(String.valueOf(fin));
                           lbMMid.setText(String.valueOf(mid));
                           
                           if (total >= 80) {
                               lbMGrade.setText("A");
                           } else if (total >= 60 && total < 80) {
                               lbMGrade.setText("B");
                           } else if (total >= 50 && total < 60) {
                               lbMGrade.setText("C");
                           } else if (total >= 40 && total < 50) {
                               lbMGrade.setText("D");
                           } else {
                               lbMGrade.setText("F");
                           }
                       }
                       if(arrOfStr[11].equalsIgnoreCase("math")){
                           fM = 1;
                           int mid = Integer.parseInt(arrOfStr[12]);
                           int fin = Integer.parseInt(arrOfStr[13]);
                           int total = mid + fin;
                           
                           lbMFinal.setText(String.valueOf(fin));
                           lbMMid.setText(String.valueOf(mid));
                           
                           if (total >= 80) {
                               lbMGrade.setText("A");
                           } else if (total >= 60 && total < 80) {
                               lbMGrade.setText("B");
                           } else if (total >= 50 && total < 60) {
                               lbMGrade.setText("C");
                           } else if (total >= 40 && total < 50) {
                               lbMGrade.setText("D");
                           } else {
                               lbMGrade.setText("F");
                           }
                       }
                       if(arrOfStr[5].equalsIgnoreCase("science")){
                           fS = 1;
                           int mid = Integer.parseInt(arrOfStr[6]);
                           int fin = Integer.parseInt(arrOfStr[7]);
                           int total = mid + fin;
                           
                           lbSFinal.setText(String.valueOf(fin));
                           lbSMid.setText(String.valueOf(mid));
                           
                           if (total >= 80) {
                               lbSGrade.setText("A");
                           } else if (total >= 60 && total < 80) {
                               lbSGrade.setText("B");
                           } else if (total >= 50 && total < 60) {
                               lbSGrade.setText("C");
                           } else if (total >= 40 && total < 50) {
                               lbSGrade.setText("D");
                           } else {
                               lbSGrade.setText("F");
                           }
                       }
                       if(arrOfStr[8].equalsIgnoreCase("science")){
                           fS = 1;
                           int mid = Integer.parseInt(arrOfStr[9]);
                           int fin = Integer.parseInt(arrOfStr[10]);
                           int total = mid + fin;
                           
                           lbSFinal.setText(String.valueOf(fin));
                           lbSMid.setText(String.valueOf(mid));
                           
                           if (total >= 80) {
                               lbSGrade.setText("A");
                           } else if (total >= 60 && total < 80) {
                               lbSGrade.setText("B");
                           } else if (total >= 50 && total < 60) {
                               lbSGrade.setText("C");
                           } else if (total >= 40 && total < 50) {
                               lbSGrade.setText("D");
                           } else {
                               lbSGrade.setText("F");
                           }
                       }
                       if(arrOfStr[11].equalsIgnoreCase("science")){
                           fS = 1;
                           int mid = Integer.parseInt(arrOfStr[12]);
                           int fin = Integer.parseInt(arrOfStr[13]);
                           int total = mid + fin;
                           
                           lbSFinal.setText(String.valueOf(fin));
                           lbSMid.setText(String.valueOf(mid));
                           
                           if (total >= 80) {
                               lbSGrade.setText("A");
                           } else if (total >= 60 && total < 80) {
                               lbSGrade.setText("B");
                           } else if (total >= 50 && total < 60) {
                               lbSGrade.setText("C");
                           } else if (total >= 40 && total < 50) {
                               lbSGrade.setText("D");
                           } else {
                               lbSGrade.setText("F");
                           }
                       }
                       if(arrOfStr[5].equalsIgnoreCase("english")){
                           fE = 1;
                           int mid = Integer.parseInt(arrOfStr[6]);
                           int fin = Integer.parseInt(arrOfStr[7]);
                           int total = mid + fin;
                           
                           lbEFinal.setText(String.valueOf(fin));
                           lbEMid.setText(String.valueOf(mid));
                           
                           if (total >= 80) {
                               lbEGrade.setText("A");
                           } else if (total >= 60 && total < 80) {
                               lbEGrade.setText("B");
                           } else if (total >= 50 && total < 60) {
                               lbEGrade.setText("C");
                           } else if (total >= 40 && total < 50) {
                               lbEGrade.setText("D");
                           } else {
                               lbEGrade.setText("F");
                           }
                       }
                       if(arrOfStr[8].equalsIgnoreCase("english")){
                           fE = 1;
                           int mid = Integer.parseInt(arrOfStr[9]);
                           int fin = Integer.parseInt(arrOfStr[10]);
                           int total = mid + fin;
                           
                           lbEFinal.setText(String.valueOf(fin));
                           lbEMid.setText(String.valueOf(mid));
                           
                           if (total >= 80) {
                               lbEGrade.setText("A");
                           } else if (total >= 60 && total < 80) {
                               lbEGrade.setText("B");
                           } else if (total >= 50 && total < 60) {
                               lbEGrade.setText("C");
                           } else if (total >= 40 && total < 50) {
                               lbEGrade.setText("D");
                           } else {
                               lbEGrade.setText("F");
                           }
                       }
                       if(arrOfStr[11].equalsIgnoreCase("english")){
                           fE = 1;
                           int mid = Integer.parseInt(arrOfStr[12]);
                           int fin = Integer.parseInt(arrOfStr[13]);
                           int total = mid + fin;
                           
                           lbEFinal.setText(String.valueOf(fin));
                           lbEMid.setText(String.valueOf(mid));
                           
                           if (total >= 80) {
                               lbEGrade.setText("A");
                           } else if (total >= 60 && total < 80) {
                               lbEGrade.setText("B");
                           } else if (total >= 50 && total < 60) {
                               lbEGrade.setText("C");
                           } else if (total >= 40 && total < 50) {
                               lbEGrade.setText("D");
                           } else {
                               lbEGrade.setText("F");
                           }
                       }
                    }else if(arrOfStr.length > 9){
                        
                         if(arrOfStr[5].equalsIgnoreCase("math")){
                           fM = 1;
                           int mid = Integer.parseInt(arrOfStr[6]);
                           int fin = Integer.parseInt(arrOfStr[7]);
                           
                           int total = mid + fin;
                           
                           lbMFinal.setText(String.valueOf(fin));
                           lbMMid.setText(String.valueOf(mid));
                           
                           if (total >= 80) {
                               lbMGrade.setText("A");
                           } else if (total >= 60 && total < 80) {
                               lbMGrade.setText("B");
                           } else if (total >= 50 && total < 60) {
                               lbMGrade.setText("C");
                           } else if (total >= 40 && total < 50) {
                               lbMGrade.setText("D");
                           } else {
                               lbMGrade.setText("F");
                           }
                       }
                       if(arrOfStr[8].equalsIgnoreCase("math")){
                           fM = 1;
                           int mid = Integer.parseInt(arrOfStr[9]);
                           int fin = Integer.parseInt(arrOfStr[10]);
                           int total = mid + fin;
                           
                           lbMFinal.setText(String.valueOf(fin));
                           lbMMid.setText(String.valueOf(mid));
                           
                           if (total >= 80) {
                               lbMGrade.setText("A");
                           } else if (total >= 60 && total < 80) {
                               lbMGrade.setText("B");
                           } else if (total >= 50 && total < 60) {
                               lbMGrade.setText("C");
                           } else if (total >= 40 && total < 50) {
                               lbMGrade.setText("D");
                           } else {
                               lbMGrade.setText("F");
                           }
                       }
                       
                       if(arrOfStr[5].equalsIgnoreCase("science")){
                           fS = 1;
                           int mid = Integer.parseInt(arrOfStr[6]);
                           int fin = Integer.parseInt(arrOfStr[7]);
                           int total = mid + fin;
                           
                           lbSFinal.setText(String.valueOf(fin));
                           lbSMid.setText(String.valueOf(mid));
                           
                           if (total >= 80) {
                               lbSGrade.setText("A");
                           } else if (total >= 60 && total < 80) {
                               lbSGrade.setText("B");
                           } else if (total >= 50 && total < 60) {
                               lbSGrade.setText("C");
                           } else if (total >= 40 && total < 50) {
                               lbSGrade.setText("D");
                           } else {
                               lbSGrade.setText("F");
                           }
                       }
                       if(arrOfStr[8].equalsIgnoreCase("science")){
                           fS = 1;
                           int mid = Integer.parseInt(arrOfStr[9]);
                           int fin = Integer.parseInt(arrOfStr[10]);
                           int total = mid + fin;
                           
                           lbSFinal.setText(String.valueOf(fin));
                           lbSMid.setText(String.valueOf(mid));
                           
                           if (total >= 80) {
                               lbSGrade.setText("A");
                           } else if (total >= 60 && total < 80) {
                               lbSGrade.setText("B");
                           } else if (total >= 50 && total < 60) {
                               lbSGrade.setText("C");
                           } else if (total >= 40 && total < 50) {
                               lbSGrade.setText("D");
                           } else {
                               lbSGrade.setText("F");
                           }
                       }
                       
                       if(arrOfStr[5].equalsIgnoreCase("english")){
                           fE = 1;
                           int mid = Integer.parseInt(arrOfStr[6]);
                           int fin = Integer.parseInt(arrOfStr[7]);
                           int total = mid + fin;
                           
                           lbEFinal.setText(String.valueOf(fin));
                           lbEMid.setText(String.valueOf(mid));
                           
                           if (total >= 80) {
                               lbEGrade.setText("A");
                           } else if (total >= 60 && total < 80) {
                               lbEGrade.setText("B");
                           } else if (total >= 50 && total < 60) {
                               lbEGrade.setText("C");
                           } else if (total >= 40 && total < 50) {
                               lbEGrade.setText("D");
                           } else {
                               lbEGrade.setText("F");
                           }
                       }
                       if(arrOfStr[8].equalsIgnoreCase("english")){
                           fE = 1;
                           int mid = Integer.parseInt(arrOfStr[9]);
                           int fin = Integer.parseInt(arrOfStr[10]);
                           int total = mid + fin;
                           
                           lbEFinal.setText(String.valueOf(fin));
                           lbEMid.setText(String.valueOf(mid));
                           
                           if (total >= 80) {
                               lbEGrade.setText("A");
                           } else if (total >= 60 && total < 80) {
                               lbEGrade.setText("B");
                           } else if (total >= 50 && total < 60) {
                               lbEGrade.setText("C");
                           } else if (total >= 40 && total < 50) {
                               lbEGrade.setText("D");
                           } else {
                               lbEGrade.setText("F");
                           }
                       }
                        
                    }else if(arrOfStr.length > 6){
                        
                        
                        if(arrOfStr[5].equalsIgnoreCase("math")){
                           fM = 1;
                           int mid = Integer.parseInt(arrOfStr[6]);
                           int fin = Integer.parseInt(arrOfStr[7]);
                           
                           int total = mid + fin;
                           
                           lbMFinal.setText(String.valueOf(fin));
                           lbMMid.setText(String.valueOf(mid));
                           
                           if (total >= 80) {
                               lbMGrade.setText("A");
                           } else if (total >= 60 && total < 80) {
                               lbMGrade.setText("B");
                           } else if (total >= 50 && total < 60) {
                               lbMGrade.setText("C");
                           } else if (total >= 40 && total < 50) {
                               lbMGrade.setText("D");
                           } else {
                               lbMGrade.setText("F");
                           }
                       }
                        
                        if(arrOfStr[5].equalsIgnoreCase("science")){
                           fS = 1;
                           int mid = Integer.parseInt(arrOfStr[6]);
                           int fin = Integer.parseInt(arrOfStr[7]);
                           int total = mid + fin;
                           
                           lbSFinal.setText(String.valueOf(fin));
                           lbSMid.setText(String.valueOf(mid));
                           
                           if (total >= 80) {
                               lbSGrade.setText("A");
                           } else if (total >= 60 && total < 80) {
                               lbSGrade.setText("B");
                           } else if (total >= 50 && total < 60) {
                               lbSGrade.setText("C");
                           } else if (total >= 40 && total < 50) {
                               lbSGrade.setText("D");
                           } else {
                               lbSGrade.setText("F");
                           }
                       }
                        
                        
                        if(arrOfStr[5].equalsIgnoreCase("english")){
                           fE = 1;
                           int mid = Integer.parseInt(arrOfStr[6]);
                           int fin = Integer.parseInt(arrOfStr[7]);
                           int total = mid + fin;
                           
                           lbEFinal.setText(String.valueOf(fin));
                           lbEMid.setText(String.valueOf(mid));
                           
                           if (total >= 80) {
                               lbEGrade.setText("A");
                           } else if (total >= 60 && total < 80) {
                               lbEGrade.setText("B");
                           } else if (total >= 50 && total < 60) {
                               lbEGrade.setText("C");
                           } else if (total >= 40 && total < 50) {
                               lbEGrade.setText("D");
                           } else {
                               lbEGrade.setText("F");
                           }
                       }
                        
                    }
                    
                    if(fM == 0){
                        lbMFinal.setText("0");
                        lbMMid.setText("0");
                        lbMGrade.setText("F");
                    }else if(fS == 0){
                        lbSFinal.setText("0");
                        lbSMid.setText("0");
                        lbSGrade.setText("F");
                    }else if(fE == 0){
                        lbEFinal.setText("0");
                        lbEMid.setText("0");
                        lbEGrade.setText("F");
                    }
                    
                    lbMMid.setVisible(true);
                    lbMFinal.setVisible(true);
                    lbMGrade.setVisible(true);
                    lbSMid.setVisible(true);
                    lbSFinal.setVisible(true);
                    lbSGrade.setVisible(true);
                    lbEMid.setVisible(true);
                    lbEFinal.setVisible(true);
                    lbEGrade.setVisible(true);
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(ViewBasicInfoController.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }else{
                
                Alert a = new Alert(Alert.AlertType.ERROR);
                a.setContentText("File Not Exists");
                a.show();
            }
            }
    }

    @FXML
    private void btnMMClick(ActionEvent event) throws IOException {
        Stage stage;
        Scene scene;
        Parent root;
        
        
        root = FXMLLoader.load(getClass().getResource("MainMenu.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setTitle("Main Menu");
        stage.setScene(scene);
        stage.show();
    }
    
}
