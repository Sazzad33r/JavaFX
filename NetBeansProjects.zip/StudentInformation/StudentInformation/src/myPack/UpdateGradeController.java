package myPack;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Sazzad
 */
public class UpdateGradeController implements Initializable {

    @FXML
    private TextField tfID;
    @FXML
    private TextField tfMid;
    @FXML
    private TextField tfFinal;
    @FXML
    private ComboBox<String> cbSubject;
    @FXML
    private Label lbTotal;
    @FXML
    private Label lbGrade;

    
    String ID;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        ID = "";
        ObservableList<String> options = 
    FXCollections.observableArrayList(
        "Math",
        "Science",
        "English"
    );
        
        cbSubject.setItems(options);
    }    

    @FXML
    private void btnSearchClick(ActionEvent event) {
        
        if (!tfID.getText().equals("")) {
            ID = tfID.getText();

            String fileName = ID + ".txt";

            File file1 = new File(fileName);

            if (ID.equals("")) {
                Alert a = new Alert(Alert.AlertType.ERROR);
                a.setContentText("Please Enter An ID");
                a.show();
            } else {
                if (file1.exists()) {
                    tfMid.setDisable(false);
                    tfFinal.setDisable(false);
                } else {
                    Alert a = new Alert(Alert.AlertType.ERROR);
                    a.setContentText("File Not Exists");
                    a.show();
                }
            }
        }else{
            Alert a = new Alert(Alert.AlertType.ERROR);
                    a.setContentText("Please Enter and ID");
                    a.show();
        }
    }

    @FXML
    private void tfMTChanged(InputMethodEvent event) {
        int value = Integer.parseInt(tfMid.getText());
        if(value > 40){
            Alert a = new Alert(Alert.AlertType.ERROR);
            a.setContentText("Max 40 is permitted");
            a.show();
            tfMid.setText("");
        }else{
            if (!tfMid.getText().equals("") && !tfFinal.getText().equals("")) {
                int mid = Integer.parseInt(tfMid.getText());
                int fin = Integer.parseInt(tfFinal.getText());
                int total = mid + fin;

                lbTotal.setText(String.valueOf(total));
                if (total >= 80) {
                    lbGrade.setText("A");
                } else if (total >= 60 && total < 80) {
                    lbGrade.setText("B");
                } else if (total >= 50 && total < 60) {
                    lbGrade.setText("C");
                } else if (total >= 40 && total < 50) {
                    lbGrade.setText("D");
                } else {
                    lbGrade.setText("F");
                }
            }
        }
    }

    @FXML
    private void tfFChanged(InputMethodEvent event) {
        int value = Integer.parseInt(tfFinal.getText());
        if(value>60){
            Alert a = new Alert(Alert.AlertType.ERROR);
            a.setContentText("Max 40 is permitted");
            a.show();
            tfFinal.setText("");
        }else{
            if (!tfMid.getText().equals("") && !tfFinal.getText().equals("")) {
                int mid = Integer.parseInt(tfMid.getText());
                int fin = Integer.parseInt(tfFinal.getText());
                int total = mid + fin;

                lbTotal.setText(String.valueOf(total));
                if (total >= 80) {
                    lbGrade.setText("A");
                } else if (total >= 60 && total < 80) {
                    lbGrade.setText("B");
                } else if (total >= 50 && total < 60) {
                    lbGrade.setText("C");
                } else if (total >= 40 && total < 50) {
                    lbGrade.setText("D");
                } else {
                    lbGrade.setText("F");
                }
            }
        }
    }
    
    @FXML
    private void tfMTKey(KeyEvent event){
        
        int value = Integer.parseInt(tfMid.getText());
        if(value > 40){
            Alert a = new Alert(Alert.AlertType.ERROR);
            a.setContentText("Max 40 is permitted");
            a.show();
            tfMid.setText("");
        }else{
            if (!tfMid.getText().equals("") && !tfFinal.getText().equals("")) {
                int mid = Integer.parseInt(tfMid.getText());
                int fin = Integer.parseInt(tfFinal.getText());
                int total = mid + fin;

                lbTotal.setText(String.valueOf(total));
                if (total >= 80) {
                    lbGrade.setText("A");
                } else if (total >= 60 && total < 80) {
                    lbGrade.setText("B");
                } else if (total >= 50 && total < 60) {
                    lbGrade.setText("C");
                } else if (total >= 40 && total < 50) {
                    lbGrade.setText("D");
                } else {
                    lbGrade.setText("F");
                }
            }
        }
    }
    
    
    @FXML
    private void tfFKey(KeyEvent event){
        
        int value = Integer.parseInt(tfFinal.getText());
        if(value>60){
            Alert a = new Alert(Alert.AlertType.ERROR);
            a.setContentText("Max 40 is permitted");
            a.show();
            tfFinal.setText("");
        }else{
            if (!tfMid.getText().equals("") && !tfFinal.getText().equals("")) {
                int mid = Integer.parseInt(tfMid.getText());
                int fin = Integer.parseInt(tfFinal.getText());
                int total = mid + fin;

                lbTotal.setText(String.valueOf(total));
                if (total >= 80) {
                    lbGrade.setText("A");
                } else if (total >= 60 && total < 80) {
                    lbGrade.setText("B");
                } else if (total >= 50 && total < 60) {
                    lbGrade.setText("C");
                } else if (total >= 40 && total < 50) {
                    lbGrade.setText("D");
                } else {
                    lbGrade.setText("F");
                }
            }
        }
    }

    @FXML
    private void btnSaveClick(ActionEvent event) throws IOException {
        
        if (!ID.equals("")) {
            String appendText;
            String fileName = ID + ".txt";
            if (!tfMid.getText().equals("") && !tfFinal.getText().equals("")) {
                if (cbSubject.getValue().equalsIgnoreCase("Math") || cbSubject.getValue().equalsIgnoreCase("Science") || cbSubject.getValue().equalsIgnoreCase("English")) {

                    if (cbSubject.getValue().equalsIgnoreCase("Math")) {

                        appendText = "Math&" + Integer.parseInt(tfMid.getText()) + "&" + Integer.parseInt(tfFinal.getText()) + "&";

                    } else if (cbSubject.getValue().equalsIgnoreCase("Science")) {

                        appendText = "Science&" + Integer.parseInt(tfMid.getText()) + "&" + Integer.parseInt(tfFinal.getText()) + "&";

                    } else {

                        appendText = "English&" + Integer.parseInt(tfMid.getText()) + "&" + Integer.parseInt(tfFinal.getText()) + "&";

                    }

                    try ( BufferedWriter output = new BufferedWriter(
                            new FileWriter(fileName, true))) {
                        output.write(appendText);
                    }

                } else {
                    Alert a = new Alert(Alert.AlertType.ERROR);
                    a.setContentText("Select a subject please!");
                    a.show();
                }
            } else {
                Alert a = new Alert(Alert.AlertType.ERROR);
                a.setContentText("Enter Mid and Final Marks!");
                a.show();
            }
        }else{
            Alert a = new Alert(Alert.AlertType.ERROR);
                a.setContentText("ID is NULL!");
                a.show();
        }
        
    }

    @FXML
    private void btnMMClick(ActionEvent event) throws IOException {
        Stage stage;
        Scene scene;
        Parent root;
        
        
        root = FXMLLoader.load(getClass().getResource("MainMenu.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setTitle("Main Menu");
        stage.setScene(scene);
        stage.show();
    }
    
}
