package myPack;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Sazzad
 */
public class ViewBasicInfoController implements Initializable {

    @FXML
    private TextField tfID;
    @FXML
    private Label lbName;
    @FXML
    private Label lbID;
    @FXML
    private Label lbAge;
    @FXML
    private Label lbClass;
    @FXML
    private Label lbDob;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void btnShowClick(ActionEvent event) throws IOException{
        
        String ID = tfID.getText();
        List<String> student = new ArrayList<String>();
        
        if(ID.equals("")){
            Alert a = new Alert(Alert.AlertType.ERROR);
            a.setContentText("Please Enter An ID");
            a.show();
        }else{
            //String curDir = System.getProperty("user.dir");
            //String fileName = curDir + "\"" + ID + ".txt";
            
            String fileName = ID + ".txt";
            
            File file1 = new File(fileName);
            
            if(file1.exists()){
                   
                try {
                    BufferedReader bf = new BufferedReader(
                    new FileReader(fileName));
                    
                    String line = bf.readLine();
                    
                    while (line != null) {
                        student.add(line);
                        line = bf.readLine();
                        
                        
                        }
                    
                    
                    bf.close();
                    
                    String[] array = student.toArray(new String[0]);
                    String[] arrOfStr = array[0].split("&");
                    
                    lbName.setText(arrOfStr[0]);
                    lbName.setVisible(true);
                    lbID.setText(arrOfStr[1]);
                    lbID.setVisible(true);
                    lbAge.setText(arrOfStr[2]);
                    lbAge.setVisible(true);
                    lbClass.setText(arrOfStr[3]);
                    lbClass.setVisible(true);
                    lbDob.setText(arrOfStr[4]);
                    lbDob.setVisible(true);
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(ViewBasicInfoController.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }else{
                
                Alert a = new Alert(Alert.AlertType.ERROR);
                a.setContentText("File Not Exists");
                a.show();
            }
            }
        }
    
    
    @FXML
    private void btnMMClick(ActionEvent event) throws IOException{
        Stage stage;
        Scene scene;
        Parent root;
        
        
        root = FXMLLoader.load(getClass().getResource("MainMenu.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setTitle("Main Menu");
        stage.setScene(scene);
        stage.show();
    }
    
}
