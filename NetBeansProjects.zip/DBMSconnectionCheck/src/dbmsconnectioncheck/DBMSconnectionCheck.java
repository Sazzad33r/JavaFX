/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dbmsconnectioncheck;

import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.*;

/**
 *
 * @author Sazzad
 */
public class DBMSconnectionCheck {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        try {
            String query="";
            // TODO code application logic here
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String dburl = "jdbc:sqlserver://DESKTOP-LT0EOH2\\SQLEXPRESS;databaseName=test;integratedSecurity=true;trustServerCertificate=true;";
            Connection con = DriverManager.getConnection(dburl);
            Statement stat = con.createStatement();
            query = "update info set Name = 'Asadullah' where ID = 4";
            stat.executeUpdate(query);
//            query = "delete from info where ID = 6";
//            stat.executeUpdate(query);
//            String query = "insert into info values('Manik', 'Admin Officer')";
//            stat.executeUpdate(query);
            query = "select * from info";
            ResultSet rs = stat.executeQuery(query);
            while(rs.next()){
                System.out.println(rs.getString(1)+ "-" + rs.getString(2) + "-" + rs.getString(3));
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DBMSconnectionCheck.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
}
