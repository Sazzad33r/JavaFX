module com.example.online_banking {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.online_banking to javafx.fxml;
    exports com.example.online_banking;
}