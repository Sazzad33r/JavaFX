package com.example.online_banking;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;

public class HelloApplication extends Application {
    public static Stage primaryStage;
    public static ArrayList<Client> client= new ArrayList<>();
    public static BigInteger giveAccountNumber= new BigInteger("100000000000");
    @Override
    public void start(Stage stage) throws IOException {
        primaryStage=stage;
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Home_Page.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1280, 720);
        primaryStage.setTitle("FincUraa");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
class Client{
    String name;
    String number;
    String password;
    double balance;
    String email;
    BigInteger accountNumber;
    public Client(String name,String number,String password, String email,BigInteger accountNumber){
        this.name=name;
        this.number=number;
        this.password= password;
        this.balance=0;
        this.email=email;
        this.accountNumber=accountNumber;
    }
}