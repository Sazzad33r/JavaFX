package com.example.online_banking;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class HelloController {

    @FXML
    private TextField country_number_tf;

    @FXML
    private Button forgot_passwordButton;

    @FXML
    private Button loginButton;

    @FXML
    private TextField number_tf;

    @FXML
    private PasswordField password_tf;

    @FXML
    private Button sign_upButton;

    @FXML
    void moveToAccountCreatePage(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("create_Account.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1280, 720);
        Stage stage= (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    void adminLogin(ActionEvent event) throws IOException {
        for(Client Admin: HelloApplication.client){
            if(Admin.number.equals(country_number_tf.getText()+number_tf.getText()) && Admin.password.equals(password_tf)){
                FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Dashboard.fxml"));
                Scene scene = new Scene(fxmlLoader.load(), 1280, 720);
                Stage stage= (Stage)((Node)event.getSource()).getScene().getWindow();
                stage.setScene(scene);
                stage.show();
                BufferedWriter bw = new BufferedWriter(new FileWriter("Admin.txt"));
                bw.write(Admin.name+"%&%"+Admin.number+"%&%"+Admin.email+"%&%"+Admin.balance);
                bw.close();
            }
        }
    }

}
