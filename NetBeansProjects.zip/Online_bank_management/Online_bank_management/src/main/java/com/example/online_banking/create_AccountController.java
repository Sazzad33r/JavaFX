package com.example.online_banking;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;

public class create_AccountController {

    @FXML
    private Button continue_button;

    @FXML
    private TextField country_number_tf;

    @FXML
    private TextField email_tf;

    @FXML
    private TextField name_tf;

    @FXML
    private TextField number_tf;

    @FXML
    private PasswordField password;

    @FXML
    private Label warning_tf;

    @FXML
    void create_Account(ActionEvent event)throws IOException {

        if(name_tf.getText()=="" && number_tf.getText()=="" && password.getText()=="" && country_number_tf.getText()=="" && email_tf.getText()==""){
            warning_tf.setText("WARNING: Complete Every Text Field!");
        }
        else if(country_number_tf.getText().length()>3){
            warning_tf.setText("WARNING: Invalid Number!");
        }
        else if(!email_tf.getText().contains("@")){
            warning_tf.setText("WARNING: Invalid Email Address!");
        }
        else if (HelloApplication.client.isEmpty()){
            HelloApplication.client.add(new Client(name_tf.getText(), country_number_tf.getText()+number_tf.getText(),password.getText(),email_tf.getText(),HelloApplication.giveAccountNumber));
            BufferedWriter bw= new BufferedWriter(new FileWriter("info.txt",true));
            bw.append(name_tf.getText()+"%&%"+country_number_tf.getText()+number_tf.getText()+"%&%"+email_tf.getText()+"%&%"+HelloApplication.giveAccountNumber+"\n");
            BigInteger A= BigInteger.ONE;
            HelloApplication.giveAccountNumber.add(A);
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Dashboard.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 1280, 720);
            Stage stage= (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
            }
        else {
            Client c1= new Client(name_tf.getText(), country_number_tf.getText()+number_tf.getText(),password.getText(),email_tf.getText(),HelloApplication.giveAccountNumber);
            if(findExistence(c1)){
                warning_tf.setText("ID already exist!");
            }else{
                HelloApplication.client.add(c1);
                BufferedWriter bw= new BufferedWriter(new FileWriter("info.txt",true));
                bw.append(name_tf.getText()+"%&%"+country_number_tf.getText()+number_tf.getText()+"%&%"+email_tf.getText()+"%&%"+HelloApplication.giveAccountNumber+"\n");
                BigInteger A= BigInteger.ONE;
                HelloApplication.giveAccountNumber.add(A);
                FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Dashboard.fxml"));
                Scene scene = new Scene(fxmlLoader.load(), 1280, 720);
                Stage stage= (Stage)((Node)event.getSource()).getScene().getWindow();
                stage.setScene(scene);
                stage.show();

                //setting texts on dashboard requires; taratari kam sesh kor hala...
            }

        }
    }
    boolean findExistence(Client s1){
        for(Client s2:HelloApplication.client){
            if(s2.number.equals(s1.number))
                return true;
        }
        return false;
    }

}
